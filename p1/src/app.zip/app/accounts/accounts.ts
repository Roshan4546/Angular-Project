import { Component } from '@angular/core';

@Component({
  selector: 'app-accounts',
  standalone: false,
  templateUrl: './accounts.html',
  styleUrl: './accounts.css'
})
export class Accounts {

}
