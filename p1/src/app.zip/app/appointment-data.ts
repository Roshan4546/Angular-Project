export class AppointmentData {
  id: number = 0;
  name: string = "";
  age: string = "";
  symptoms: string = "";
  number: string = "";
}
