import { Component } from '@angular/core';

@Component({
  selector: 'app-ambulatory',
  standalone: false,
  templateUrl: './ambulatory.html',
  styleUrl: './ambulatory.css'
})
export class Ambulatory {

}
