import { Component } from '@angular/core';

@Component({
  selector: 'app-pharmacy',
  standalone: false,
  templateUrl: './pharmacy.html',
  styleUrl: './pharmacy.css'
})
export class Pharmacy {

}
