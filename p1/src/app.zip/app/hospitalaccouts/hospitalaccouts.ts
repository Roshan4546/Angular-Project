import { Component } from '@angular/core';

@Component({
  selector: 'app-hospitalaccouts',
  standalone: false,
  templateUrl: './hospitalaccouts.html',
  styleUrl: './hospitalaccouts.css'
})
export class Hospitalaccouts {

}
