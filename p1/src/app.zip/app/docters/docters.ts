import { Component } from '@angular/core';

@Component({
  selector: 'app-docters',
  standalone: false,
  templateUrl: './docters.html',
  styleUrl: './docters.css'
})
export class Docters {

}
