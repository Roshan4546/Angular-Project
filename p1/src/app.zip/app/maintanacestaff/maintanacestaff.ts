import { Component } from '@angular/core';

@Component({
  selector: 'app-maintanacestaff',
  standalone: false,
  templateUrl: './maintanacestaff.html',
  styleUrl: './maintanacestaff.css'
})
export class Maintanacestaff {

}
