import { Component } from '@angular/core';

@Component({
  selector: 'app-department',
  standalone: false,
  templateUrl: './department.html',
  styleUrl: './department.css'
})
export class Department {

}
