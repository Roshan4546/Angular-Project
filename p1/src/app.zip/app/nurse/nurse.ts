import { Component } from '@angular/core';

@Component({
  selector: 'app-nurse',
  standalone: false,
  templateUrl: './nurse.html',
  styleUrl: './nurse.css'
})
export class Nurse {

}
