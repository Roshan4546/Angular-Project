import { AppointmentData } from './appointment-data';

describe('AppointmentData', () => {
  it('should create an instance', () => {
    expect(new AppointmentData()).toBeTruthy();
  });
});
